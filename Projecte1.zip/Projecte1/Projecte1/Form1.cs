﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;

namespace Projecte1
{
    public partial class Form1 : Form
    {
        Socket server;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //desconnectar
            string miss = "0/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(miss);
            server.Send(msg);
            this.BackColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //connectar
            IPAddress direc = IPAddress.Parse("192.168.56.101");
            IPEndPoint ipep = new IPEndPoint(direc, 9070);

            //creem socket
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);
                this.BackColor= Color.Green;
                MessageBox.Show("Connectat");
               

               /* this.BackColor = Color.Gray;
                server.Shutdown(SocketShutdown.Both);
                server.Close(); 
                */
            }
            catch(SocketException ex)
            {
                MessageBox.Show("No s'ha pogut connectar amb el servidor");
                return;
            }
            


        }
    }
}

#include <mysql.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <ctype.h>
#include<stdbool.h>  
#include <pthread.h>

MYSQL_RES *resultado;
int err;
MYSQL_ROW row; 
MYSQL *conn;

int i;

int sockets[100];

int contador; //numero servicios
int id;

//Acceso exluyente
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

//Almacenar 100 usuarios conectados

typedef struct{ 
	char nombre[20];
	int socket;
}Conectado;

//Lista conectados
typedef struct{ 
	Conectado conectados[100];
	int num;
}ListaConectados;

ListaConectados milista;
		
//Declaramos la lista de Partidas, de 4 jugadores cada una
typedef struct {
	int ID;
	int numJugadores;
	char tablero[30];
	//Sockets
	char nombre1[20];
	char nombre2[20];
	char nombre3[20];
	char nombre4[20];

	int sock[4];
}Partida;

typedef struct {
	Partida Partidas [100];
	int num;
} ListaPartidas;
	
	
ListaPartidas miListaPartidas;

int AnadeConectado (ListaConectados *lista, char nombre[20], int socket) //A�ade a la lista un nuevo usuario conectado
{
	if (lista->num == 100)
	{
		return -1; //Est� la lista llena
	}
	else
	{
		strcpy(lista->conectados[lista->num].nombre, nombre);
		lista->conectados[lista->num].socket = socket;
		lista->num++;
		return 0; //Se ha a�adido correctamente
	}
}
		

	int DameSocket(ListaConectados *lista, char nombre[20])
	{
		int j = 0;
		int encontrado = 0;
		while (encontrado == 0 && j< lista->num){
			if(strcmp(lista->conectados[j].nombre,nombre) == 0)
				encontrado = 1;
			else
				j = j + 1;
		}
		if (encontrado == 0)
			return -1;
		else
			return lista->conectados[j].socket; //Devuelve el socket
	}
	
	//Saber posicion usuario
	int GetPosicion (ListaConectados *lista, char nombre[20])
	{
		int i = 0;
		int encontrado = 0;
		while((i < lista->num) && !encontrado)
		{
			if (strcmp(lista->conectados[i].nombre,nombre) == 0)
			{
				encontrado = 1;
			}
			else 
				i++;
		}
		if (encontrado)
		{
			return lista->conectados[i].socket; //Devuelve el socket
		}
		else
		{
			return -1; //No est� en la lista
		}
	}
	
	int EliminarConectado(char nombre[20],ListaConectados *lista,char respuestaDes[512])
	{
		int p = GetPosicion(nombre,lista);
		
		if(p == -1)
			return -1;
		else{
			int i;
			for(i = p; i < lista -> num; i++){
				lista->conectados[i].socket = lista->conectados[i+1].socket;
				strcpy(lista->conectados[i].nombre,lista->conectados[i+1].nombre);
				
				
			}
			lista->num = lista->num -1;
			sprintf(respuestaDes, "0/ Te has desconectado");
			return 0;
			
		}
	}
	void DameConectados(ListaConectados *lista, char conectado[200]) //Pone en el vector de conectados el numero de usuarios en la lista y el usuario de cada jugador separado por "/"
	{
		sprintf(conectado,"%d/",lista->num);
		int i;
		for(i = 0; i < lista->num; i++){
			sprintf(conectado,"%s%s/",conectado,lista->conectados[i].nombre);
		}
	}
	
	//Funcion para iniciar sesi�n, guarda en respuesta 1/incorrecto o inicio session completado
		void InicioSesion(char usuario[20], char contrasena[20], char consulta[80], char respuesta1[512], int codigo, char conectado[300], int sock_conn)
	{
		printf ("Codigo: %d, Nombre: %s, Contrasena: %s\n", codigo, usuario, contrasena);
		
		sprintf(consulta, "SELECT jugadores.usuario, jugadores.pass FROM jugadores WHERE (jugadores.usuario='%s' AND jugadores.pass='%s')",usuario,contrasena);
		err=mysql_query(conn, consulta);
		if (err!=0)
		{
			printf ("Error al consultar datos de la base %u %s\n", mysql_errno(conn),mysql_error(conn));
			exit(1);
		}
		//Recogemos el resultado de la consulta
		resultado = mysql_store_result(conn);
		row = mysql_fetch_row(resultado);
		
		if (row == NULL)
		{
			printf("No se ha obtenido la consulta \n");
			sprintf(respuesta1,"1/INCORRECTO");
			write(sock_conn, respuesta1, strlen(respuesta1));
			
			
		}
		else
		{
			printf("Inicio de sesion completado \n");
			pthread_mutex_lock( &mutex );
			AnadeConectado(&milista, usuario, sock_conn);
			pthread_mutex_unlock( &mutex);
			
			
		}
	}
	
	//Funcion registrarse
	int Registro (char usuario[20],char contrasena[20], char respuesta2[512], char consulta[80], int id) 
	{
		printf("%s\n", usuario);
		sprintf(consulta, "SELECT jugadores.usuario FROM jugadores WHERE jugadores.usuario='%s'",usuario);
		printf("Consulta: %s\n", consulta);
		// hacemos la consulta para saber si ese usuario ya est� registrado
		int err =mysql_query (conn, consulta);
		resultado = mysql_store_result (conn);
		row=mysql_fetch_row(resultado);
		
		printf("row: %s\n", row);
		printf("hola %d\n", err);
		if (row == NULL)
		{
			printf("Voy a a�adir este usuario: %s\n", usuario);
			
			/*int idJugador = atoi(row[0]);*/
			char insert[150];
			sprintf(insert,"INSERT INTO jugadores (usuario, pass) VALUES('%s','%s');",usuario,contrasena); 
			err=mysql_query(conn, insert);
			if (err!=0)
			{
				printf ("Error al insertar datos de la base %u %s\n", mysql_errno(conn), mysql_error(conn));
				exit (1);
				sprintf(respuesta2,"2/No se ha podido insertar el usuario");          		 
			}
			else
			{
				sprintf(respuesta2,"2/Registrado correctamente");
				printf("Se ha registrado correctamente el usuario: %s\n", usuario);
			}
		}
		else
		{
			sprintf(respuesta2,"2/No se ha podido acceder a la base de datos");
		} 
		
		if (err !=0)
		{
			printf ("Error al consultar datos de la base %u %s\n", mysql_errno(conn),mysql_error(conn));
			exit(1);
		}
		
		
	}
			

void *AtencionCliente(void*socket)
{
	//Crear conexion al servidor MYSQL
	

	
	int sock_conn;
	int *s;
	s=(int *)socket;
	sock_conn= *s;
	char notificacion[512];
	char peticion[512];
	char respuesta[512];
	int  sock_listen;
	int ret;
	char conectado[100];
	int desconectar=0;
	
	int terminar = 0;
	
	while(terminar == 0) //Bucle de atencion al cliente
	{
		char usuario[80];
		char contrasena[80];
		int id;
		
		
		ret = read(sock_conn, peticion, sizeof(peticion));
		printf("Recibido \n");
		
		peticion[ret]='\0';
		
		printf("Peticion %s \n", peticion);
		
		char *p = strtok(peticion, "/");
		int codigo = atoi(p);
		int cont;
		char jugador1 [10];
		char jugador2 [10];
		char consulta [80];	
		
		//peticiones
		
		if(codigo==0) //Desconexion y eliminar de lista Conectados
		{
			terminar = 1;
			desconectar=1;
			pthread_mutex_lock( &mutex );
			EliminarConectado(&milista,usuario,respuesta);
			char conectados[300];
			DameConectados(&milista, conectados);
			pthread_mutex_unlock( &mutex);
			
			char notificacion[512];
			sprintf(notificacion, "3/%s",conectados);
			printf("La respuesta es: %s\n", notificacion);
			
			int i;
			for (i=0; i < milista.num ; i++) 
				write (milista.conectados[i].socket, notificacion, strlen (notificacion));
		
		}
		else if(codigo == 1) //inicio sesion
		{
			p=strtok(NULL,"/");
			strcpy(usuario,p);
			p=strtok(NULL,"/");
			strcpy(contrasena,p);

			
			InicioSesion(usuario,contrasena, consulta, respuesta, codigo, conectado,sock_conn); //Lamamos a la funcion InicioSesion
			pthread_mutex_lock( &mutex );
			char conectados[300];
			DameConectados(&milista,conectados);
			pthread_mutex_unlock( &mutex);
			sprintf(notificacion, "3/%s",conectados);
			printf("La respuesta es: %s\n", notificacion);
			int i;
			for (i=0; i < milista.num ; i++) 
				write (milista.conectados[i].socket, notificacion, strlen (notificacion));
			desconectar=0;
		}
		else if (codigo == 2){ //Registro usuario
			p = strtok( NULL, "/");
		strcpy (usuario, p);
		p = strtok( NULL, "/");
		strcpy(contrasena,p);
		Registro(usuario,contrasena, respuesta, consulta, id);
		//Enviamos la respuesta
		printf("Respuesta: %s \n", respuesta);
		write(sock_conn, respuesta, strlen(respuesta));
		}
	
		
		else if (codigo==3) //lista ConectadosAutomatico
		{
			printf("Voy a arrancar los nombres de usuario\n");
			pthread_mutex_lock( &mutex );
			char conectados[300];
			DameConectados(&milista, conectados);
			pthread_mutex_unlock( &mutex);
			
			sprintf(notificacion, "3/%s",conectados);
			printf("La respuesta es: %s\n", notificacion);
			int i;
			for (i=0; i < milista.num ; i++) 
				write (milista.conectados[i].socket, notificacion, strlen (notificacion));
		}
	}
	close(sock_conn);
}
int main(int argc, char *argv[])//crear socket para conexion
{
	int sock_conn, sock_listen;
	struct sockaddr_in serv_adr;
	
	if((sock_listen = socket(AF_INET, SOCK_STREAM, 0))<0)
		printf("Error creando el socket\n");
	
	memset(&serv_adr,0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_adr.sin_port = htons(9035);//socket que usamos
	if(bind(sock_listen, (struct sockaddr *)&serv_adr, sizeof(serv_adr))<0)
		printf("Error al bind \n");
	
	if(listen(sock_listen, 100)<0)
		printf("Error en el listen \n");
	//Creamos la conexi�n con SQL
	

	conn = mysql_init(NULL);
   if (conn==NULL) {
	printf ("Error al crear la conexion: %u %s\n", 
			mysql_errno(conn), mysql_error(conn));
	exit (1);
    }
     milista.num=0;

//inicializar la conexion
   conn = mysql_real_connect (conn, "localhost","root", "mysql", "juego",0, NULL, 0);
    if (conn==NULL) {
	printf ("Error al inicializar la conexion: %u %s\n", 
			mysql_errno(conn), mysql_error(conn));
	exit (1);
    }
    contador=0;
	pthread_t thread;
    i=0;
    char usuario[20];

   for(;;) //bucle para atender a los clientes
	{
	printf("Escuchando \n");
	
	sock_conn=accept(sock_listen, NULL, NULL);
	printf("He recibido conexi�n\n");
	
	sockets[i]=sock_conn; //Socket que usaremos para este cliente
	
	pthread_create(&thread, NULL, AtencionCliente,&sockets[i]); //Crear Thread
	i=i+1;	
	}	
}
			
			
		
			
		}
		
		if (codigo!=0)
		{
		printf("respuesta:%s\n", respuesta);
		//y lo enviamos
		write(sock_conn, respuesta, strlen(respuesta));
		}
		
		//se acabo el servicio para este cliente
		close(sock_conn);
		
		
	}
	

}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Diagnostics.Eventing.Reader;
using System.Net.NetworkInformation;



namespace Ejercicio_Guia_Q2
{
    public partial class Form1 : Form
    {
        Socket server;
        Thread atender;

        // variables de cada partida
        string[] jugadores = new string[3];
        int jug = 0;
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;  //necesario para que los elementos de los formularios puedan ser
            //accedidos desde threads diferentes a los que se crearon

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void Form2_Load(object sender, EventArgs e) //Iniciamos la conexión
        {
            
        }

        private void AtenderServidor()
        {
            //recibimos respuesta del servidor
            while(true)
            {
                //recibimos respuesta del servidor
                byte[] msg2 = new byte[80];
                this.server.Receive(msg2);
                string mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                string[] trozos = mensaje.Split('/');
               
                int codigo = Convert.ToInt32(trozos[0]);

                switch (codigo)
                {
                    case 0: // Desconexion
                        
                        MessageBox.Show("Te has desconectado");
                       
                        break;

                    case 1: // inicio sesion

                        if (trozos[1] != "INCORRECTO")
                        {

                           

                            MessageBox.Show("Se ha conectado correctamente" + textBox1.Text);
                            this.BackColor = Color.Green;

                        }
                        else
                        {
                            MessageBox.Show("Nombre de usuario o contraseña incorrecta");
                        }
                        break;
                    case 2: //registrarse
                        if (mensaje == "2/Registrado correctamente")
                        {
                            MessageBox.Show("Usuario registrado correctamente");
                        }
                        else if (mensaje == "2/No se ha podido registrar al usuario")
                        {
                            MessageBox.Show("No se ha podido insertar el usuario");
                        }
                        else
                        {
                            MessageBox.Show("No se ha podido acceder a la base de datos");

                        }
                        break;


                    case 3: //Lista conectados

                        //Recibir respuesta del servidor
                        Invoke(new Action(() =>
                        {
                            //Recibimos la respuesta del servidor
                            dataGridView1.Rows.Clear();
                            int num = Convert.ToInt32(trozos[1]);
                            dataGridView1.RowCount = num;
                            for (int i = 0; i < num; i++)
                            {
                                dataGridView1.Rows[i].Cells[0].Value = trozos[i + 2];
                            }
                            this.dataGridView1.Rows[0].Cells[0].Selected = false;
                        }));
                        break;

                        break;




                }
            }
        }

        private void inicio_click_Click(object sender, EventArgs e)
        {
            //Creamos un IDEndPoint con el IP y puerto del servidor
            IPAddress direc = IPAddress.Parse("192.168.56.102");
            IPEndPoint ipep = new IPEndPoint(direc, 9035);

            //Acceso shiva:
            //IPAddress direc = IPAddress.Parse("147.83.117.22");
            //IPEndPoint ipep = new IPEndPoint(direc, puerto);

            //Creamos el socket
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep); //Intentamos conectar el socket
               

                //Enviar nombre y contraseña 

                string mensaje = "1/" + textBox1.Text + "/" + pass.Text;
                //enviamos mensaje al servidor
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                
                
            }
            catch (SocketException exc)
            {
                MessageBox.Show("No se ha podido conectar con el servidor");
                return;
            }
            //pongo en marcha el thread
            ThreadStart ts = delegate { AtenderServidor(); };
            atender = new Thread(ts);
            atender.Start();

            

        }

        private void Desconectar_click_Click(object sender, EventArgs e)
        {
            string mensaje = "0/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
            this.BackColor = Color.Gray;
            dataGridView1.Columns.Clear();
            MessageBox.Show("Te has desconectado");
            //Cerrar conexion
            server.Shutdown(SocketShutdown.Both);
            server.Close();
            atender.Abort();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e) //registro
        {
            if (((textBox2.Text.Length > 1) && (textBox3.Text.Length > 1)) && ((textBox2.Text != "") && (textBox3.Text != ""))) //Que tenga un mínimo de longitud y no esté en blanco
            {
                string mensaje = "2/" + textBox2.Text + "/" + textBox3.Text;
                // Enviamos al servidor el mensaje
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            else
            {
                MessageBox.Show("El nombre debe tener más de un caracter");
            }
        }

        private void Conectados_click_Click(object sender, EventArgs e)
        {
            string mensaje = "3/" + textBox1.Text + "/" + textBox2.Text;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            
        }
    }
}
